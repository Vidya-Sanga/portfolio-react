import React from 'react'

export const Product = () => {
  return (
    <div>
      
    </div>
  )
}
export default Product
