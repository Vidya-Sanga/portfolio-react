import React from 'react'

export const LoginSignup = () => {
  return (
    <div></div>
  )
}
export default LoginSignup
